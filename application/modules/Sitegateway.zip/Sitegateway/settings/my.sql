/**

 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Sitegateway
 * @copyright  Copyright 2015-2016 BigStep Technologies Pvt. Ltd.
 * @license    http://www.socialengineaddons.com/license/
 * @version    my.sql 2015-09-10 00:00:00Z SocialEngineAddOns $
 * @author     SocialEngineAddOns
 */
INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('sitegateway', 'Advanced Payment Gateways / Stripe Connect /  PayPal Adaptive ', 'Advanced Payment Gateways / Stripe Connect /  PayPal Adaptive ', '4.9.2', 1, 'extra');