<?php

class Sescustomize_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}