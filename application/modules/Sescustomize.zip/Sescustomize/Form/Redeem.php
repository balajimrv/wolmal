<?php

class Sescustomize_Form_Redeem extends Engine_Form {

  public function init() {

    $this->setTitle('Amount Reedem Form')
            ->setDescription('');
    $id = Zend_Controller_Front::getInstance()->getRequest()->getParam('id');
    $settings = Engine_Api::_()->getApi('settings', 'core');
    
    
    $this->addElement('Text', 'balance_total', array(
        'label' => 'Total Balance',
        'description' => 'Your ToTal Balance Left?', 
        'disabled'=>'disabled',       
    ));
    $this->addElement('Text', 'amount', array(
        'label' => 'Requested Amount',
        'description' => 'Amount Requested', 
        'required'=>true,
        'allowEmpty'=>false,
        'validators' => array(
          array('Int', true),
          array('GreaterThan', true, array(0)),
      ),
    ));
   $this->addElement('Textarea', 'note', array(
        'label' => 'Note',
        'description' => '', 
    ));
    $this->addElement('Text', 'bank_name', array(
        'label' => 'Bank Name',
        'required'=>true,
        'allowEmpty'=>false,
        'description' => '', 
    ));
   
   
   $this->addElement('Text', 'ifsc_code', array(
        'label' => 'IFSC Code',
        'required'=>true,
        'allowEmpty'=>false,
        'description' => '', 
    ));
    $this->addElement('Text', 'account_number', array(
        'label' => 'Acount Number',
        'required'=>true,
        'allowEmpty'=>false,
        'description' => '', 
    ));
    $this->addElement('Text', 'account_holder_name', array(
        'label' => 'Account Holder Name',
        'required'=>true,
        'allowEmpty'=>false,
        'description' => '', 
    ));
    $this->addElement('Text', 'monile_number', array(
        'label' => 'Mobile Number',
        'required'=>true,
        'allowEmpty'=>false,
        'description' => '', 
    ));
    $viewer = Engine_Api::_()->user()->getViewer();
    if($viewer->level_id == 1){
      $this->addElement('Textarea', 'admin_note', array(
          'label' => 'Admin Note',
          'description' => '', 
      ));
    }
    

    if(empty($id)){
// Buttons
    $this->addElement('Button', 'submit', array(
        'label' => 'Create',
        'type' => 'submit',
        'ignore' => true,
        'decorators' => array('ViewHelper')
    ));

    $this->addElement('Cancel', 'cancel', array(
        'label' => 'Cancel',
        'link' => true,
        'prependText' => ' or ',
        'href' => '',
        'onClick' => 'javascript:parent.Smoothbox.close();',
        'decorators' => array(
            'ViewHelper'
        )
    ));
    $this->addDisplayGroup(array('submit', 'cancel'), 'buttons');
  }else{
     $this->addElement('Button', 'cancel_form', array(
        'label' => 'Cancel',
        'link' => true,
        'href' => '',
        'onClick' => 'javascript:parent.Smoothbox.close();',
        'decorators' => array(
            'ViewHelper'
        )
    ));  
  }
  }

}
