<?php

class Sescustomize_AdminManageController extends Core_Controller_Action_Admin {
  public function ebvalueAction(){
      $this->view->navigation = Engine_Api::_()->getApi('menus', 'core')->getNavigation('sescustomize_admin_main', array(), 'sescustomize_admin_main_ebbb');
      
      $table = Engine_Api::_()->getDbTable('ebvalues','sescustomize');
      $selectEb = $table->select()->from($table->info('name'),array('ebcount'=>new Zend_db_Expr('SUM(total)')))->where('type =?','insert');
      $result = $table->fetchRow($selectEb);
      $this->view->ebCount = $result->ebcount;
      
      $table = Engine_Api::_()->getDbTable('bridges','sesbasic');
      $selectBB = $table->select()->from($table->info('name'),array('bbcount'=>new Zend_db_Expr('SUM(buyer_bb)')));
      $result = $table->fetchRow($selectBB);
      $this->view->Cobbunt = $result->bbcount;
      
  }
  public function indexAction() {
    
    $this->view->navigation = Engine_Api::_()->getApi('menus', 'core')->getNavigation('sescustomize_admin_main', array(), 'sescustomize_admin_main_manage');
    
    $endDate = strtotime("- 5 year");
    $endDate = strtotime("+ 2 months",$endDate);
    
    $this->view->formFilter = $formFilter = new Sescustomize_Form_Admin_Manage_Filter();
    $page = $this->_getParam('page', 1);

    $table = Engine_Api::_()->getDbtable('users', 'user');
    $select = $table->select()
              ->where('DATE_FORMAT(creation_date,"%Y-%m-%d") <= ?', date("Y-m-d",$endDate));
    // Process form
    $values = array();
    if ($formFilter->isValid($this->_getAllParams())) {
      $values = $formFilter->getValues();
    }
    
    if(isset($_GET['action']))
    $formFilter->getElement('action')->setValue($_GET['action']);

    foreach ($values as $key => $value) {
      if (null === $value) {
        unset($values[$key]);
      }
    }
    $values = array_merge(array(
        'order' => 'user_id',
        'order_direction' => 'DESC',
            ), $values);

    $this->view->assign($values);

    // Set up select info
    $select->order((!empty($values['order']) ? $values['order'] : 'user_id' ) . ' ' . (!empty($values['order_direction']) ? $values['order_direction'] : 'DESC' ));

    if (!empty($values['displayname'])) {
      $select->where('displayname LIKE ?', '%' . $values['displayname'] . '%');
    }
    if (!empty($values['action_status'])) {
      $select->where('extend = ?', $values['action_status']);
    }
    if (!empty($values['username'])) {
      $select->where('username LIKE ?', '%' . $values['username'] . '%');
    }
    if (!empty($values['email'])) {
      $select->where('email LIKE ?', '%' . $values['email'] . '%');
    }
    
    if (!empty($values['level_id'])) {
      $select->where('level_id = ?', $values['level_id']);
    }

    if (!empty($values['user_id'])) {
      $select->where('user_id = ?', (int) $values['user_id']);
    }

    // Filter out junk
    $valuesCopy = array_filter($values);

    // Make paginator
    $this->view->paginator = $paginator = Zend_Paginator::factory($select);
    $this->view->paginator = $paginator->setCurrentPageNumber($page);
    $this->view->formValues = $valuesCopy;

    $this->view->superAdminCount = count(Engine_Api::_()->user()->getSuperAdmins());
    $this->view->hideEmails = _ENGINE_ADMIN_NEUTER;
    $this->view->openUser = (bool) ( $this->_getParam('open') && $paginator->getTotalItemCount() == 1 );
  }
  
  public function handshakeAction() {
    
    $this->view->navigation = Engine_Api::_()->getApi('menus', 'core')->getNavigation('sescustomize_admin_main', array(), 'sescustomize_admin_main_handshake');
    
    $this->view->formFilter = $formFilter = new Sescustomize_Form_Admin_Manage_Filter();
    $page = $this->_getParam('page', 1);

    $table = Engine_Api::_()->getDbtable('users', 'user');
    $select = $table->select()->where('level_id != ?',1)->where('level_id != ?',2);
    // Process form
    $values = array();
    if ($formFilter->isValid($this->_getAllParams())) {
      $values = $formFilter->getValues();
    }
    
    if(isset($_GET['action']))
    $formFilter->getElement('action')->setValue($_GET['action']);

    foreach ($values as $key => $value) {
      if (null === $value) {
        unset($values[$key]);
      }
    }
    $values = array_merge(array(
        'order' => 'user_id',
        'order_direction' => 'DESC',
            ), $values);

    $this->view->assign($values);

    // Set up select info
    $select->order((!empty($values['order']) ? $values['order'] : 'user_id' ) . ' ' . (!empty($values['order_direction']) ? $values['order_direction'] : 'DESC' ));

    if (!empty($values['displayname'])) {
      $select->where('displayname LIKE ?', '%' . $values['displayname'] . '%');
    }
    if (!empty($values['username'])) {
      $select->where('username LIKE ?', '%' . $values['username'] . '%');
    }
    if (!empty($values['email'])) {
      $select->where('email LIKE ?', '%' . $values['email'] . '%');
    }
    
    if (!empty($values['level_id'])) {
      $select->where('level_id = ?', $values['level_id']);
    }

    if (!empty($values['user_id'])) {
      $select->where('user_id = ?', (int) $values['user_id']);
    }

    // Filter out junk
    $valuesCopy = array_filter($values);

    // Make paginator
    $this->view->paginator = $paginator = Zend_Paginator::factory($select);
    $this->view->paginator = $paginator->setCurrentPageNumber($page);
    $this->view->formValues = $valuesCopy;
    
    $this->view->hideEmails = _ENGINE_ADMIN_NEUTER;
    $this->view->openUser = (bool) ( $this->_getParam('open') && $paginator->getTotalItemCount() == 1 );
  }
  
  public function statsAction() {
      
    $id = $this->_getParam('id', null);
    $this->view->user = $user = Engine_Api::_()->getItem('user', $id);

    // posts
    $table = Engine_Api::_()->getDbTable('actions', 'activity');
    $this->view->post_count = $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('subject_id =?',$id)
      ->query()
      ->fetchColumn();
      
    $this->view->share_count = $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('type =?','share')
      ->where('subject_id =?',$id)
      ->query()
      ->fetchColumn();
      
    $like_count = 0;
    $table = Engine_Api::_()->getDbTable('likes', 'activity');
    $like_count += (int) $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('poster_id =?',$id)
      ->query()
      ->fetchColumn();

    $table = Engine_Api::_()->getDbTable('likes', 'core');
    $like_count += (int) $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('poster_id =?',$id)
      ->query()
      ->fetchColumn();

    $this->view->like_count = $like_count;
    // comments
    $comment_count = 0;
    
    $table = Engine_Api::_()->getDbTable('comments', 'activity');
    $comment_count += (int) $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('poster_id =?',$id)
      ->query()
      ->fetchColumn();

    $table = Engine_Api::_()->getDbTable('comments', 'core');
    $comment_count += (int) $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('poster_id =?',$id)
      ->query()
      ->fetchColumn();

    $this->view->comment_count = $comment_count;

    $table = Engine_Api::_()->getDbTable('photos', 'album');
    $this->view->photo_count = $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('owner_id =?',$id)
      ->query()
      ->fetchColumn();
      
    $table = Engine_Api::_()->getDbTable('albums', 'album');
    $this->view->album_count = $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('owner_id =?',$id)
      ->query()
      ->fetchColumn();
    $table = Engine_Api::_()->getDbTable('videos', 'video');
    $this->view->video_count = $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('owner_id =?',$id)
      ->query()
      ->fetchColumn();
    $table = Engine_Api::_()->getDbTable('orders', 'sitestoreproduct');
    $this->view->product_purchased = $table->select()
      ->from($table, array(
        'COUNT(*) AS count',
      ))
      ->where('buyer_id =?',$id)
      ->where('payment_status =?','active')
      ->query()
      ->fetchColumn();

  }
  
  public function extendUserAction() {
    $id = $this->_getParam('id', null);
    $this->view->user = $user = Engine_Api::_()->getItem('user', $id);
    $this->view->form = $form = new Sescustomize_Form_Admin_Manage_Extend();
    $date = strtotime("+ 5 years", strtotime($user->creation_date));
    if ($this->getRequest()->isPost()) {
      $db = Engine_Api::_()->getDbtable('users', 'user')->getAdapter();
      $db->beginTransaction();
      try {
        $user->extend = 0;
        $user->expiry_date = date("Y-m-d", $date);
        $user->save();
        $db->commit();
      } catch (Exception $e) {
        $db->rollBack();
        throw $e;
      }
      return $this->_forward('success', 'utility', 'core', array(
                  'smoothboxClose' => true,
                  'parentRefresh' => true,
                  'format' => 'smoothbox',
                  'messages' => array('This member will deactive automatically after 5 Years Completion of his/her account.')
      ));
    }
  }
  
  public function invitationAction() {
    $id = $this->_getParam('id', null);
    $user = Engine_Api::_()->getItem('user', $id);
    $this->view->form = $form = new Sescustomize_Form_Admin_Manage_Invitation();
    if (!$this->getRequest()->isPost()) {
      return;
    }
    if (!$form->isValid($this->getRequest()->getPost())) {
      return;
    }
    $inviteTable = Engine_Api::_()->getDbTable('invites','inviter');
    $isExist = $inviteTable->select()
                ->from($inviteTable->info('name'), 'new_user_id')
                ->where('new_user_id =?', $_POST['member_id'])
                ->query()
                ->fetchColumn();
    if($isExist) {
        return $form->getElement('member_id')->addError('This member id is already associated with someone..');
    }
      $newUser = Engine_Api::_()->getItem('user', $_POST['member_id']);
      $db = $inviteTable->getAdapter();
      $db->beginTransaction();
      try {
        $inviter = $inviteTable->createRow();
        $inviter->user_id = $user->user_id;
        $inviter->sender = $user->email;
        $inviter->recipient = $newUser->email;
        $inviter->sent_date = date('Y-m-d H:i:s');
        $inviter->message = 'You are being invited to join our social network.';
        $inviter->new_user_id = $_POST['member_id'];
        $inviter->recipient_name = $newUser->displayname;
        $inviter->referred_date = date('Y-m-d H:i:s');
        $inviter->save();
        $db->commit();
      } catch (Exception $e) {
        $db->rollBack();
        throw $e;
      }
      return $this->_forward('success', 'utility', 'core', array(
                  'smoothboxClose' => true,
                  'parentRefresh' => true,
                  'format' => 'smoothbox',
                  'messages' => array('This member has been invited successfully.')
      ));
        
  }

}
