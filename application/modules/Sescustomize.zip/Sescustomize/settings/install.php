<?php

class Sescustomize_Installer extends Engine_Package_Installer_Module {

  public function onInstall() {
    parent::onInstall();
  }

}
