<?php

class Sescustomize_Plugin_Task_Jobs extends Core_Plugin_Task_Abstract {
    public function execute() { 
        
        if(date('d') != 25)
            return true;
        
        $db = Engine_Db_Table::getDefaultAdapter(); 
        $dateBack  = date('Y-m-d',strtotime('-1 Month',time()));
        $dateYM = date('Y-m',strtotime($dateBack));
        $bridgeTable = Engine_Api::_()->getDbTable('bridges', 'sesbasic');
        $table2 = $bridgeTable->info('name');
        $tableName = $bridgeTable->info('name');
        $selectTable = $bridgeTable->select()
                       ->from($tableName, array('eb_count'=>new Zend_Db_Expr("(SUM($tableName.buyer_bb) + SUM($tableName.buyer_cb) + SUM($tableName.buyer_db)) * engine4_sescustomize_bbvalues.value"),$tableName.".buyer_user_id"))
                       ->where('DATE_FORMAT('.$tableName.'.creation_date,"%Y-%m") =?', $dateYM)
                       ->setIntegrityCheck(false)
                       ->joinLeft('engine4_sescustomize_bbvalues','engine4_sescustomize_bbvalues.date = DATE_FORMAT('.$tableName.'.creation_date,"%m-%Y")',null)
                       ->join($table2,'engine4_sesbasic_bridges_2.buyer_user_id = '.$tableName.'.buyer_user_id AND DATE_FORMAT(engine4_sesbasic_bridges_2.creation_date,"%Y-%m") = "'.$dateYM.'" AND engine4_sesbasic_bridges_2.buyer_bb != 0',null)
                       ->having("COUNT(engine4_sesbasic_bridges_2.bridge_id) > 0")
                       ->group("$tableName.buyer_user_id")
                       ->group("YEAR($tableName.creation_date)")
                       ->group("MONTH($tableName.creation_date)");
        $querySub = "UPDATE engine4_users u1 JOIN (".$selectTable.") b1 ON (u1.user_id = b1.buyer_user_id AND bb_update_date != '".$dateYM."') SET u1.eb_count = b1.eb_count,bb_update_date = '".$dateYM."'" ;   
        $db->query($querySub);
         return true;
    }

}