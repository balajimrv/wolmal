<?php defined('_ENGINE') or die('Access Denied'); return array (
  0 => 1,
  'environment_mode' => 'production',
  'maintenance' => 
  array (
    'enabled' => false,
    'code' => 'izva5',
  ),
); ?>