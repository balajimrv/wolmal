<?php defined('_ENGINE') or die('Access Denied'); return array (
  'class' => 'Zend_Mail_Transport_Sendmail',
  'args' => 
  array (
  ),
); ?>