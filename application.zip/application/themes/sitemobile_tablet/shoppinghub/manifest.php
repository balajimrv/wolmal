<?php return array (
  'package' => 
  array (
    'type' => 'theme',
    'name' => 'shoppinghub',
    'version' => NULL,
    'path' => 'application/themes/sitemobile_tablet/shoppinghub',
    'repository' => 'socialengineaddons.com',
    'title' => 'Shopping Hub',
    'thumb' => 'thumb.jpg',
    'author' => 'SocialEngineAddOns',
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'remove',
    ),
    'callback' => 
    array (
      'class' => 'Engine_Package_Installer_Theme',
    ),
    'directories' => 
    array (
      0 => 'application/themes/sitemobile_tablet/shoppinghub',
    ),
    'description' => '',
  ),
  'files' => 
  array (
    0 => 'theme.css',
    1 => 'structure.css',
    
  ),
); ?>
