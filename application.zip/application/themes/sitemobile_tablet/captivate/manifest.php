<?php return array (
  'package' => 
  array (
    'type' => 'theme',
    'name' => 'Captivate',
    'version' => NULL,
    'path' => 'application/themes/sitemobile_tablet/captivate',
    'repository' => 'socialengineaddOns.com',
    'title' => 'Captivate Theme',
    'thumb' => 'thumb.jpg',
    'author' => 'SocialEngineAddons',
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'remove',
    ),
    'callback' => 
    array (
      'class' => 'Engine_Package_Installer_Theme',
    ),
    'directories' => 
    array (
      0 => 'application/themes/sitemobile_tablet/captivate',
    ),
    'description' => '',
  ),
  'files' => 
  array (
    0 => 'theme.css',
    1 => 'structure.css',
  ),
); ?>