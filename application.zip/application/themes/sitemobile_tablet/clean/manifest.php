<?php return array (
  'package' => 
  array (
    'type' => 'theme',
    'name' => 'clean',
    'version' => NULL,
    'path' => 'application/themes/sitemobile_tablet/clean',
    'repository' => 'socialengineaddons.com',
    'title' => 'Clean',
    'thumb' => 'thumb.jpg',
    'author' => 'SocialEngineAddOns',
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'remove',
    ),
    'callback' => 
    array (
      'class' => 'Engine_Package_Installer_Theme',
    ),
    'directories' => 
    array (
      0 => 'application/themes/sitemobile_tablet/clean',
    ),
    'description' => '',
  ),
  'files' => 
  array (
    0 => 'theme.css',
    1 => 'structure.css',
   
  ),
); ?>
