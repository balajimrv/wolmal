<?php return array (
  'package' => 
  array (
    'type' => 'theme',
    'name' => 'clear',
    'version' => NULL,
    'revision' => '$Revision: 9747 $',
    'path' => 'application/themes/sitemobile_tablet/clear',
    'repository' => 'socialengineaddOns.com',
    'title' => 'Clear',
    'thumb' => 'thumb.jpg',
    'author' => 'My Community',
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'remove',
    ),
    'callback' => 
    array (
      'class' => 'Engine_Package_Installer_Theme',
    ),
    'directories' => 
    array (
      0 => 'application/themes/sitemobile_tablet/clear',
    ),
    'description' => 'Clear',
  ),
  'files' => 
  array (
    0 => 'theme.css',
    1 => 'structure.css',
  ),
); ?>