<?php return array (
  'package' => 
  array (
    'type' => 'theme',
    'name' => 'gray',
    'version' => NULL,
    'path' => 'application/themes/sitemobile_tablet/gray',
    'repository' => 'socialengineaddons.com',
    'title' => 'Gray Theme',
    'thumb' => 'thumb.jpg',
    'author' => 'SocialEngineAddOns',
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'remove',
    ),
    'callback' => 
    array (
      'class' => 'Engine_Package_Installer_Theme',
    ),
    'directories' => 
    array (
      0 => 'application/themes/sitemobile_tablet/gray',
    ),
    'description' => '',
  ),
  'files' => 
  array (
    0 => 'theme.css',
    1 => 'structure.css',
    
  ),
); ?>
